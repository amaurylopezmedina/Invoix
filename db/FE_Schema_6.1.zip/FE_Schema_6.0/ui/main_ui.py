
import os
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from schema_manager import run_install, conectar_y_validar
from ui.json_manager_ui import JsonManagerWindow
from ui.log_window import LogWindow
from tools.export_schema import export_schema_and_open

APP_TITLE = "FE Schema Manager 6.1 - Desktop"

class MainUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("980x620")
        self.minsize(900, 580)

        # --------- Estilo "Fluent" básico ----------
        self._configure_style()

        self.ambiente_var = tk.StringVar(value="DEV")
        self.operator_var = tk.StringVar(value=os.getenv("USERNAME") or os.getenv("USER") or "")

        self._build_layout()

    # -------------------------------------------------
    # ESTILO
    # -------------------------------------------------
    def _configure_style(self):
        self.configure(bg="#0f172a")  # fondo oscuro tipo dashboard
        style = ttk.Style(self)
        style.theme_use("clam")

        style.configure(
            "Card.TFrame",
            background="#020617",
            relief="flat",
            borderwidth=1,
        )
        style.configure(
            "Header.TLabel",
            background="#0f172a",
            foreground="#e5e7eb",
            font=("Segoe UI", 16, "bold"),
        )
        style.configure(
            "SubHeader.TLabel",
            background="#0f172a",
            foreground="#9ca3af",
            font=("Segoe UI", 9),
        )
        style.configure(
            "Accent.TButton",
            font=("Segoe UI", 10, "bold"),
            padding=8,
        )
        style.map(
            "Accent.TButton",
            background=[("!disabled", "#2563eb"), ("pressed", "#1d4ed8"), ("active", "#1d4ed8")],
            foreground=[("!disabled", "white")],
        )
        style.configure(
            "Ghost.TButton",
            font=("Segoe UI", 10),
            padding=6,
            background="#020617",
            foreground="#e5e7eb",
            borderwidth=0,
        )
        style.map(
            "Ghost.TButton",
            background=[("pressed", "#111827"), ("active", "#111827")],
        )
        style.configure(
            "TLabel",
            background="#020617",
            foreground="#e5e7eb",
            font=("Segoe UI", 10),
        )
        style.configure(
            "TEntry",
            fieldbackground="#0b1120",
            foreground="#e5e7eb",
        )
        style.configure(
            "TCombobox",
            fieldbackground="#0b1120",
            foreground="#e5e7eb",
        )

    # -------------------------------------------------
    # LAYOUT PRINCIPAL
    # -------------------------------------------------
    def _build_layout(self):
        # ----- Header -----
        header = ttk.Frame(self, style="Card.TFrame")
        header.pack(side=tk.TOP, fill=tk.X, padx=16, pady=(12, 8))

        lbl_title = ttk.Label(header, text="FE Schema Manager", style="Header.TLabel")
        lbl_title.grid(row=0, column=0, sticky="w")

        lbl_sub = ttk.Label(
            header,
            text="Gestión de tablas, vistas y SP de facturación electrónica • Modo profesional",
            style="SubHeader.TLabel",
        )
        lbl_sub.grid(row=1, column=0, sticky="w")

        # Ambiente + Operador en header derecho
        right = ttk.Frame(header, style="Card.TFrame")
        right.grid(row=0, column=1, rowspan=2, sticky="e", padx=8)

        ttk.Label(right, text="Ambiente").grid(row=0, column=0, sticky="e", padx=4)
        cmb = ttk.Combobox(
            right,
            textvariable=self.ambiente_var,
            values=["DEV", "CERT", "PRD"],
            width=7,
            state="readonly",
        )
        cmb.grid(row=0, column=1, sticky="w")

        ttk.Label(right, text="Operador").grid(row=1, column=0, sticky="e", padx=4, pady=(4, 0))
        op_entry = ttk.Entry(right, textvariable=self.operator_var, width=18)
        op_entry.grid(row=1, column=1, sticky="w", pady=(4, 0))

        # ----- Body (cards) -----
        body = ttk.Frame(self, style="Card.TFrame")
        body.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=16, pady=8)

        body.columnconfigure(0, weight=2)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)

        # Columna izquierda: Acciones principales
        left = ttk.Frame(body, style="Card.TFrame")
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 8))

        # Card: Esquema
        card_schema = ttk.Frame(left, style="Card.TFrame", padding=16)
        card_schema.pack(fill=tk.X, pady=(0, 10))

        ttk.Label(card_schema, text="Esquema de base de datos", font=("Segoe UI", 11, "bold")).grid(
            row=0, column=0, columnspan=3, sticky="w"
        )
        ttk.Label(
            card_schema,
            text="Aplica tablas, vistas y SP desde los JSON versionados.",
            font=("Segoe UI", 9),
        ).grid(row=1, column=0, columnspan=3, sticky="w", pady=(2, 8))

        b_run = ttk.Button(
            card_schema,
            text="⚙️ Crear / Actualizar estructura",
            style="Accent.TButton",
            command=self._on_run_install,
        )
        b_run.grid(row=2, column=0, sticky="w")

        b_logs = ttk.Button(
            card_schema,
            text="📜 Ver log de ejecución",
            style="Ghost.TButton",
            command=self._open_logs,
        )
        b_logs.grid(row=2, column=1, sticky="w", padx=(8, 0))

        # Card: Configuración
        card_cfg = ttk.Frame(left, style="Card.TFrame", padding=16)
        card_cfg.pack(fill=tk.X, pady=(0, 10))

        ttk.Label(card_cfg, text="Configuración", font=("Segoe UI", 11, "bold")).grid(
            row=0, column=0, columnspan=3, sticky="w"
        )
        ttk.Label(
            card_cfg,
            text="Edita el cn_*.ini del ambiente y los archivos JSON de esquema.",
            font=("Segoe UI", 9),
        ).grid(row=1, column=0, columnspan=3, sticky="w", pady=(2, 8))

        ttk.Button(
            card_cfg, text="🛠️ Editar cn.ini del ambiente", style="Ghost.TButton",
            command=self._edit_cn_ini,
        ).grid(row=2, column=0, sticky="w")

        ttk.Button(
            card_cfg, text="🧾 Administrar JSON (tablas / vistas / SP)", style="Ghost.TButton",
            command=self._open_json_manager,
        ).grid(row=2, column=1, sticky="w", padx=(8, 0))

        # Card: Exportar
        card_export = ttk.Frame(left, style="Card.TFrame", padding=16)
        card_export.pack(fill=tk.X)

        ttk.Label(card_export, text="Exportar esquema desde BD", font=("Segoe UI", 11, "bold")).grid(
            row=0, column=0, columnspan=3, sticky="w"
        )
        ttk.Label(
            card_export,
            text="Genera JSON (tablas, vistas, SP, funciones) desde una base conectada y crea un ZIP listo para compartir.",
            font=("Segoe UI", 9),
        ).grid(row=1, column=0, columnspan=3, sticky="w", pady=(2, 8))

        ttk.Button(
            card_export,
            text="📤 Exportar esquema → ZIP",
            style="Accent.TButton",
            command=self._on_export,
        ).grid(row=2, column=0, sticky="w")

        # Columna derecha: Panel rápido
        right_panel = ttk.Frame(body, style="Card.TFrame")
        right_panel.grid(row=0, column=1, sticky="nsew")

        right_panel.rowconfigure(0, weight=1)
        right_panel.columnconfigure(0, weight=1)

        card_status = ttk.Frame(right_panel, style="Card.TFrame", padding=12)
        card_status.grid(row=0, column=0, sticky="nsew", padx=(0, 0), pady=(0, 8))

        ttk.Label(card_status, text="Estado rápido", font=("Segoe UI", 11, "bold")).grid(
            row=0, column=0, sticky="w"
        )

        self.status_text = tk.Text(
            card_status,
            height=10,
            bg="#020617",
            fg="#e5e7eb",
            relief="flat",
            padx=8,
            pady=8,
            font=("Consolas", 9),
        )
        self.status_text.grid(row=1, column=0, sticky="nsew", pady=(6, 0))
        card_status.rowconfigure(1, weight=1)
        self._append_status("Listo.\n")

    # -------------------------------------------------
    # HANDLERS
    # -------------------------------------------------
    def _append_status(self, text: str):
        self.status_text.insert(tk.END, text)
        self.status_text.see(tk.END)

    def _get_ambiente(self) -> str:
        return self.ambiente_var.get().strip().upper() or "DEV"

    def _edit_cn_ini(self):
        ambiente = self._get_ambiente()
        try:
            cn_path = os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                "config",
                f"cn_{ambiente.lower()}.ini",
            )
            if not os.path.exists(cn_path):
                messagebox.showerror("Config", f"No existe {cn_path}")
                return
            if os.name == "nt":
                os.startfile(cn_path)  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                import subprocess  # noqa
                subprocess.Popen(["open", cn_path])
            else:
                import subprocess  # noqa
                subprocess.Popen(["xdg-open", cn_path])
        except Exception as e:
            messagebox.showerror("Config", f"No se pudo abrir cn.ini: {e}")

    def _open_json_manager(self):
        JsonManagerWindow(self)

    def _open_logs(self):
        LogWindow(self)

    def _on_run_install(self):
        ambiente = self._get_ambiente()
        try:
            conectar_y_validar(ambiente)
        except Exception as e:
            messagebox.showerror("Conexión", f"Error al conectar: {e}")
            return

        if not messagebox.askyesno(
            "Aplicar estructura",
            f"¿Aplicar estructura para el ambiente {ambiente}?",
        ):
            return

        ok = run_install(ambiente)
        if ok:
            self._append_status(f"[OK] Estructura aplicada en {ambiente}.\n")
            messagebox.showinfo("Schema", "Estructura aplicada correctamente.")
        else:
            self._append_status(f"[ERROR] Hubo errores al aplicar estructura en {ambiente}.\n")
            messagebox.showerror("Schema", "Hubo errores al aplicar la estructura. Revise el log.")

    def _on_export(self):
        ambiente = self._get_ambiente()
        operator = self.operator_var.get().strip() or None

        if operator is None:
            if not messagebox.askyesno(
                "Operador vacío",
                "No se indicó operador. ¿Desea continuar de todos modos?",
            ):
                return
            operator = ""

        output_dir = filedialog.askdirectory(
            title="Seleccione carpeta destino para exportación de esquema"
        )
        if not output_dir:
            return

        try:
            zip_path, export_root = export_schema_and_open(ambiente, operator, output_dir)
        except Exception as e:
            messagebox.showerror("Exportar", f"Error exportando esquema: {e}")
            self._append_status(f"[ERROR] Exportando esquema: {e}\n")
            return

        self._append_status(
            f"[EXPORT] Esquema exportado a:\n  {zip_path}\n  Carpeta base: {export_root}\n"
        )
        messagebox.showinfo(
            "Exportar esquema",
            f"Exportación completada.\n\nZIP generado:\n{zip_path}",
        )

if __name__ == "__main__":
    app = MainUI()
    app.mainloop()
