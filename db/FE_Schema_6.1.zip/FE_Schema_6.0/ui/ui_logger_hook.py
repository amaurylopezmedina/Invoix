
try:
    from ui.log_window import ui_log
except Exception:
    ui_log = None
