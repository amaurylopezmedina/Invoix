
import os
import json
import zipfile
from datetime import datetime
from socket import gethostname, gethostbyname

from tkinter import messagebox

from schema_manager import connect

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def _ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)
    return path

def _detect_ambiente(dbname: str) -> str:
    if not dbname:
        return "DESCONOCIDO"
    u = dbname.upper()
    if "PRD" in u or "PROD" in u:
        return "PRD"
    if "CERT" in u or "QA" in u or "TEST" in u:
        return "CERT"
    if "DEV" in u:
        return "DEV"
    return "DESCONOCIDO"

def _export_tables(cur, out_dir: str) -> int:
    """
    Exporta TODAS las tablas (schema + columnas) a *.table.json
    """
    _ensure_dir(out_dir)
    sql = """
        SELECT
            s.name AS schema_name,
            t.name AS table_name,
            c.name AS column_name,
            ty.name AS data_type,
            c.max_length,
            c.precision,
            c.scale,
            c.is_nullable,
            COLUMNPROPERTY(c.object_id, c.name, 'IsIdentity') AS is_identity,
            OBJECT_DEFINITION(c.default_object_id) AS default_def,
            ISNULL(i.is_primary_key, 0) AS is_pk
        FROM sys.tables t
        JOIN sys.schemas s   ON t.schema_id = s.schema_id
        JOIN sys.columns c   ON t.object_id = c.object_id
        JOIN sys.types ty    ON c.user_type_id = ty.user_type_id
        LEFT JOIN sys.index_columns ic
          ON ic.object_id = t.object_id AND ic.column_id = c.column_id
        LEFT JOIN sys.indexes i
          ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        ORDER BY s.name, t.name, c.column_id;
    """
    cur.execute(sql)
    rows = cur.fetchall()

    tables = {}
    for row in rows:
        (schema_name, table_name, col_name, data_type,
         max_length, precision, scale,
         is_nullable, is_identity, default_def, is_pk) = row

        key = (schema_name, table_name)
        if key not in tables:
            tables[key] = {
                "type": "table",
                "name": table_name,
                "schema": schema_name,
                "description": f"Tabla {schema_name}.{table_name}",
                "fields": {}
            }

        # normalizar tipo
        data_type_l = data_type.lower()
        if data_type_l in ("char", "varchar", "nchar", "nvarchar", "binary", "varbinary"):
            if max_length == -1:
                col_type = f"{data_type} (max)"
            else:
                # max_length viene en bytes; para tipos Unicode dividir entre 2
                if data_type_l in ("nchar", "nvarchar"):
                    length = int(max_length / 2) if max_length else 0
                else:
                    length = int(max_length or 0)
                col_type = f"{data_type}({length})"
        elif data_type_l in ("decimal", "numeric"):
            col_type = f"{data_type}({precision},{scale})"
        else:
            col_type = data_type

        tables[key]["fields"][col_name] = {
            "type": col_type,
            "nullable": bool(is_nullable),
            "pk": bool(is_pk),
            "identity": bool(is_identity),
            "default": default_def,
            "description": ""
        }

    for (schema_name, table_name), cfg in tables.items():
        fname = f"{schema_name}.{table_name}.table.json"
        with open(os.path.join(out_dir, fname), "w", encoding="utf-8") as fh:
            json.dump(cfg, fh, indent=2, ensure_ascii=False)

    return len(tables)

def _export_views(cur, out_dir: str) -> int:
    _ensure_dir(out_dir)
    sql = """
        SELECT
            s.name AS schema_name,
            v.name AS view_name,
            m.definition
        FROM sys.views v
        JOIN sys.schemas s ON v.schema_id = s.schema_id
        JOIN sys.sql_modules m ON v.object_id = m.object_id
        ORDER BY s.name, v.name;
    """
    cur.execute(sql)
    rows = cur.fetchall()
    count = 0
    for schema_name, view_name, definition in rows:
        cfg = {
            "type": "view",
            "name": view_name,
            "schema": schema_name,
            "description": f"Vista {schema_name}.{view_name}",
            "execution": "replace",
            "ddl": definition
        }
        fname = f"{schema_name}.{view_name}.view.json"
        with open(os.path.join(out_dir, fname), "w", encoding="utf-8") as fh:
            json.dump(cfg, fh, indent=2, ensure_ascii=False)
        count += 1
    return count

def _export_procs(cur, out_dir: str) -> int:
    _ensure_dir(out_dir)
    sql = """
        SELECT
            s.name AS schema_name,
            p.name AS proc_name,
            m.definition
        FROM sys.procedures p
        JOIN sys.schemas s ON p.schema_id = s.schema_id
        JOIN sys.sql_modules m ON p.object_id = m.object_id
        ORDER BY s.name, p.name;
    """
    cur.execute(sql)
    rows = cur.fetchall()
    count = 0
    for schema_name, proc_name, definition in rows:
        cfg = {
            "type": "proc",
            "name": proc_name,
            "schema": schema_name,
            "description": f"Procedimiento {schema_name}.{proc_name}",
            "execution": "replace",
            "ddl": definition
        }
        fname = f"{schema_name}.{proc_name}.proc.json"
        with open(os.path.join(out_dir, fname), "w", encoding="utf-8") as fh:
            json.dump(cfg, fh, indent=2, ensure_ascii=False)
        count += 1
    return count

def _export_functions(cur, out_dir: str) -> int:
    _ensure_dir(out_dir)
    sql = """
        SELECT
            s.name AS schema_name,
            o.name AS func_name,
            m.definition
        FROM sys.objects o
        JOIN sys.schemas s ON o.schema_id = s.schema_id
        JOIN sys.sql_modules m ON o.object_id = m.object_id
        WHERE o.type IN ('FN','IF','TF','FS','FT')
        ORDER BY s.name, o.name;
    """
    cur.execute(sql)
    rows = cur.fetchall()
    count = 0
    for schema_name, func_name, definition in rows:
        cfg = {
            "type": "function",
            "name": func_name,
            "schema": schema_name,
            "description": f"Función {schema_name}.{func_name}",
            "execution": "replace",
            "ddl": definition
        }
        fname = f"{schema_name}.{func_name}.func.json"
        with open(os.path.join(out_dir, fname), "w", encoding="utf-8") as fh:
            json.dump(cfg, fh, indent=2, ensure_ascii=False)
        count += 1
    return count

def export_schema_to_folder(ambiente: str, operator: str, output_base_dir: str) -> (str, str):
    """
    Exporta Tablas + Vistas + SP + Funciones a JSON en una carpeta
    y genera un ZIP.

    Retorna: (zip_path, export_root)
    """
    if not output_base_dir:
        raise ValueError("Debe indicar una carpeta destino para la exportación.")

    cn, cur = connect(ambiente)

    cur.execute("SELECT DB_NAME(), @@SERVERNAME, APP_NAME()")
    row = cur.fetchone()
    dbname, servername, app_name = row if row else ("", "", "")

    ambiente_detectado = _detect_ambiente(dbname)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    export_root_name = f"{dbname or 'DB'}_{ts}"
    export_root = os.path.join(output_base_dir, export_root_name)

    tables_dir = _ensure_dir(os.path.join(export_root, "tables"))
    views_dir = _ensure_dir(os.path.join(export_root, "views"))
    procs_dir = _ensure_dir(os.path.join(export_root, "procs"))
    funcs_dir = _ensure_dir(os.path.join(export_root, "functions"))

    count_tables = _export_tables(cur, tables_dir)
    count_views  = _export_views(cur, views_dir)
    count_procs  = _export_procs(cur, procs_dir)
    count_funcs  = _export_functions(cur, funcs_dir)

    host = gethostname()
    try:
        ip = gethostbyname(host)
    except Exception:
        ip = None

    meta = {
        "ambiente_param": ambiente,
        "ambiente_detectado": ambiente_detectado,
        "server": servername,
        "database": dbname,
        "exported_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "operator": operator,
        "host": host,
        "ip": ip,
        "app": app_name,
        "counts": {
            "tables": count_tables,
            "views": count_views,
            "procs": count_procs,
            "functions": count_funcs,
        },
    }
    with open(os.path.join(export_root, "metadata.json"), "w", encoding="utf-8") as fh:
        json.dump(meta, fh, indent=2, ensure_ascii=False)

    # Crear ZIP
    zip_name = f"{export_root_name}.zip"
    zip_path = os.path.join(output_base_dir, zip_name)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(export_root):
            for f in files:
                full = os.path.join(root, f)
                rel = os.path.relpath(full, export_root)
                z.write(full, rel)

    try:
        cn.close()
    except Exception:
        pass

    return zip_path, export_root

def export_schema_and_open(ambiente: str, operator: str, output_base_dir: str):
    """
    Helper para UI: exporta y abre la carpeta en el explorador.
    """
    zip_path, export_root = export_schema_to_folder(ambiente, operator, output_base_dir)
    folder_to_open = os.path.dirname(zip_path)

    # Abrir carpeta en explorador
    try:
        if os.name == "nt":
            os.startfile(folder_to_open)  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            import subprocess  # noqa
            subprocess.Popen(["open", folder_to_open])
        else:
            import subprocess  # noqa
            subprocess.Popen(["xdg-open", folder_to_open])
    except Exception:
        # No es crítico si falla abrir el explorador
        pass

    return zip_path, export_root
